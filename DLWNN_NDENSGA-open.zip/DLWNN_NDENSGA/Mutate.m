function y=Mutate(x,mu,VarRange)
    mum=1;
    VarMin=VarRange(:,1);
    VarMax=VarRange(:,2);
    

    for i=1:size(x,2)
            r(i) = rand(1);
           if r(i) < 0.5
               delta(i) = (2*r(i))^(1/(mum+1)) - 1;
           else
               delta(i) = 1 - (2*(1 - r(i)))^(1/(mum+1));
           end
           xnew(i)=x(i)+delta(i);
           xnew(i)=min(max(xnew(i),VarMin(i)),VarMax(i));
    end	
   
    n=numel(x);
    m=ceil(mu*n);
    jj=randsample(n,m);
    
    y=x;
    y(jj)=xnew(jj);
    
end