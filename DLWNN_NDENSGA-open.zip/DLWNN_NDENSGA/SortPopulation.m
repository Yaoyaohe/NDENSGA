function [pop F]=SortPopulation(pop)

    % Sort according to Crowding Distance
    CD=[pop.CrowdingDistance];
    [CD CDSO]=sort(CD,'descend');
    pop=pop(CDSO);
    
    % Sort according to Rank
    R=[pop.Rank];
    [R RSO]=sort(R,'ascend');
    pop=pop(RSO);
    
    n=numel(pop);
    for i=1:n
        R(i)=pop(i).Rank;
    end
    
    Min_R=min(R);
    Max_R=max(R);

    F=cell(1,Max_R);
    emp_sit=[];

    for ii=1:Max_R

        F{ii}=find(R==ii);
        if ~isempty(F{ii})==1
            emp_sit=[emp_sit ii];
        end
    end
end