%% ��Ӧ�Ⱥ����Ĳ���
function f= DLWNN(x,train_y,train_x_norm,M,N,n,max_data,min_data)

Wjk=zeros(n,M);
for i=1:n
    Wjk(i,:)=x((M*(i-1)+1):(M*i));
end
a=x(M*n+1:M*n+n);
b=x(M*n+1+n:M*n+2*n);
Wij1=x((M*n+2*n+1):(M*n+3*n));
Wij2=x((M*n+3*n+1):(M*n+4*n));
Wik1=x((M*n+4*n+1):(M*n+4*n+M));
Wik2=x((M*n+4*n+M+1):(M*n+4*n+2*M));
Wik1=Wik1';
Wik2=Wik2';
y_f1=zeros(size(train_x_norm,1),1);
y_f2=zeros(size(train_x_norm,1),1);
%% ����ѵ��
    for kk=1:size(train_x_norm,1)
        net=zeros(1,n);
        net_ab=zeros(1,n);
        y1=0;
        y2=0;
        x_wnn=train_x_norm(kk,:);
   
        for j=1:n
            for k=1:M
                net(j)=net(j)+Wjk(j,k)*x_wnn(k);
                net_ab(j)=(net(j)-b(j))/a(j);
            end
            
            temp(j)=mymorlet(net_ab(j));
                y1=y1+Wij1(j)*temp(j);   %С������
                y2=y2+Wij2(j)*temp(j);

        end
       net_d1=x_wnn*Wik1;
       y_d1=y1+net_d1;
       net_d2=x_wnn*Wik2;
       y_d2=y2+net_d2;
       y_f1(kk)=y_d1;
       y_f2(kk)=y_d2;
       
    end

yn1=y_f1*(max_data-min_data)+min_data;
yn2=y_f2*(max_data-min_data)+min_data;

pi=zeros(size(train_x_norm,1),1);
y_w=zeros(size(train_x_norm,1),1);
for i= 1:size(train_x_norm,1)
    if (train_y(i)<yn1(i)) && (train_y(i)>yn2(i))
        pi(i)=0;
    elseif  (train_y(i)>yn1(i)) ||   (train_y(i)==yn1(i))
        pi(i)=train_y(i)-yn1(i);
    elseif (train_y(i)<yn2(i) )
        pi(i)=yn2(i)-train_y(i);
    end
    y_w(i)=yn1(i)-yn2(i);
end
PIEE=sum(pi)/((max_data-min_data)*size(train_x_norm,1));
PINAW=sum(y_w)/((max_data-min_data)*size(train_x_norm,1));

f=[PIEE
    PINAW];