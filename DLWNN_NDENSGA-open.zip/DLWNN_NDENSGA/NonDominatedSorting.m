function [pop, F]=NonDominatedSorting(pop)

    nPop=numel(pop);

    F{1}=[];
    CV=[];

for i=1:nPop
     
    c2 = -pop(i).Cost(2);

    if (c2 < 0) 
        c2 = 0;
    else
        c2=abs(c2);
    end

    CV(i)=c2;
end
tol=1e-7;
for i=1:nPop
        pop(i).DominatedCount=0;
        pop(i).DominationSet=[];
        
     for j=[1:i-1 i+1:nPop]
            
              if CV(i) == 0 && CV(j) == 0 
                if ((pop(i).Cost(1) < pop(j).Cost(1)) && (pop(i).Cost(2) < pop(j).Cost(2))) || ((abs(pop(i).Cost(1)-pop(j).Cost(1)) < tol) && (pop(i).Cost(2) <pop(j).Cost(2)))  || ((abs(pop(i).Cost(2)-pop(j).Cost(2)) < tol) && (pop(i).Cost(1) <pop(j).Cost(1)))
                    pop(i).DominationSet = [pop(i).DominationSet j];
                elseif ((pop(i).Cost(1) > pop(j).Cost(1)) && (pop(i).Cost(2) > pop(j).Cost(2))) || ((abs(pop(i).Cost(1)-pop(j).Cost(1)) < tol) && (pop(i).Cost(2) >pop(j).Cost(2)))  || ((abs(pop(i).Cost(2)-pop(j).Cost(2)) <tol) && (pop(i).Cost(1) >pop(j).Cost(1)))
                  
                    pop(i).DominatedCount = pop(i).DominatedCount + 1;
                end
              end
            if CV(i) == 0 && CV(j) ~= 0
                   pop(i).DominationSet = [pop(i).DominationSet j];
            end
            if CV(i) ~= 0 && CV(j) == 0
                   pop(i).DominatedCount = pop(i).DominatedCount + 1;
            end
            if CV(i) ~= 0 && CV(j) ~= 0
              if (CV(i) < CV(j)) 
                pop(i).DominationSet = [pop(i).DominationSet j];
              elseif CV(i) > CV(j) 
                pop(i).DominatedCount = pop(i).DominatedCount + 1;
              end   
            end 
        
          if pop(i).DominatedCount==0
             F{1}=[F{1} i];
          end
        
     end
end
    
    k=1;
    
    while ~isempty(F{k})
        
        Q=[];
        
        for i=F{k}
            for j=pop(i).DominationSet
                pop(j).DominatedCount=pop(j).DominatedCount-1;
                
                if pop(j).DominatedCount==0
                    Q=[Q j];
                end
            end
        end
        
%         if isempty(Q)
%             break;
%         end
        
        F{k+1}=Q;
        k=k+1;
        
    end
    
    for k=1:numel(F)
        for s=F{k}
            pop(s).Rank=k;
        end
    end
    
