function [x1 x2]=Crossover2(x1,x2,VarRange)
    bd=VarRange(:,1);
    bu=VarRange(:,2);
    mu=1;
    eta_c=15;
    [N,C]=size(x1);

%     y=1;
%     r1=rand;
%     if r1<=pc
 for j=1:C
                par1=x1(j);
                par2=x2(j);
                yd=bd(j);
                yu=bu(j);
                r1=rand;
                if r1<=0.5
                    r2=rand;
                    if r2<=0.5
                         u(j)=(2*r2)^(1/(mu+1));
                    else
                         u(j) = (1/(2*(1 - r2)))^(1/(mu+1));
                    end
                    chld1 =0.5*(((1 + u(j))*par1) + (1 - u(j))*par2);
                    chld2= 0.5*(((1 - u(j))*par1) + (1 + u(j))*par2);
%                         if abs(par1-par2)>10^(-14)
%                      
%                             y1=min(par1,par2);
%                             y2=max(par1,par2);
%                             betaq=1.481*randn;
%                                 if rand<0.5
%                                         chld1=0.5*((y1+y2)-betaq*(y2-y1));
%                                         chld2=0.5*((y1+y2)+betaq*(y2-y1));
%                                 else
%                                         chld1=0.5*((y1+y2)+betaq*(y2-y1));
%                                         chld2=0.5*((y1+y2)-betaq*(y2-y1));
%                                  end
                       if chld1> yu
                            chld1 =yu;
                       elseif chld1 < yd
                            chld1 = yd;
                       end
                       if chld2> yu 
                            chld2 =yu;
                       elseif chld2 <yd
                            chld2 = yd;
                       end
                       x1(j)=chld1;
                       x2(j)=chld2;
%                             aa=max(chld1,yd);
%                             x1(j)=min(aa,yu);
%                             bb=max(chld2,yd);
%                             x2(j)=min(bb,yu);
%                         end  
                end
 end
    
% end