%------------------------------- Reference --------------------------------
% He, Y., Zhu, J., & Wang, S. (2024). A Novel Neural Network-based Multiobjective 
%%Evolution Lower Upper Bound Estimation Method for Electricity Load Interval Forecast. 
%%IEEE Transactions on Systems, Man and Cybernetics: Systems. doi: 10.1109/TSMC.2024.3352665

%%Some code references from S. M. K. Heris. ��Improved-NSGA2.�� 2019. [Online]. Available: https://
%%github.com/duquanquanquan/improved-NSGA2.          


%%%data preprocessing
clear;
load('AEMO_NSW_2014.mat');
 QDATA= Demand(:,1);
 POINTS = [1,1488,2832,4320,5760,7248,8688,10176,11664,13104,14592,16032,17520];
DATA = QDATA(POINTS(1):POINTS(4));
max_data=max(DATA);
min_data=min(DATA);
samplesize = 7*48;
totalsize = length(DATA)-samplesize;
trainsize =floor(totalsize*0.7);
validationsize =floor(totalsize*0.15);
testsize=floor(totalsize*0.15);
total=zeros(totalsize,8);
for i=1:8
  total(:,i)=DATA(1+48*(i-1):totalsize+48*(i-1));
end

train=total(1:trainsize,:);
train_x=train(:,1:7);
train_y=train(:,8);
validation=total(1+trainsize:trainsize+validationsize,:);
validation_x=validation(:,1:7);
validation_y=validation(:,8);
test=total(1+trainsize+validationsize:trainsize+validationsize+testsize,:);
test_x=test(:,1:7);
test_y=test(:,8);
%��һ��֮��
DATA_norm=(DATA-min(DATA))/(max(DATA)-min(DATA));
total_norm=zeros(totalsize,8);
for i=1:8
  total_norm(:,i)=DATA_norm(1+48*(i-1):totalsize+48*(i-1));
end
train_norm=total_norm(1:trainsize,:);
train_x_norm=train_norm(:,1:7);
train_y_norm=train_norm(:,8);
validation_norm=total_norm(1+trainsize:trainsize+validationsize,:);
validation_x_norm=validation_norm(:,1:7);
validation_y_norm=validation_norm(:,8);
test_norm=total_norm(1+trainsize+validationsize:trainsize+validationsize+testsize,:);
test_x_norm=test_norm(:,1:7);
test_y_norm=test_norm(:,8);



%parameter settings
M=size(train_x,2); %the number of input nodes of DLWMM
N=2; %the number of output nodes of DLWMM
n=1; %the number of hidden nodes of DLWNN
dimsize=M*n+2*n+N*n+M*N;%%dimmension
dimMin=ones(1,dimsize);
dimMin=-dimMin;
dimMax=ones(1,dimsize);
VarSize=[1 dimsize];
dimRange=[dimMin' dimMax'];
%% NSGA-II Parameters

MaxIt=200;%%iterations

Popsize=100;%%population size

pCrossover=0.9;
nCrossover=round(pCrossover*Popsize/2)*2;

pMutation=0.1;
nMutation=round(pMutation*Popsize); 

mu=1/dimsize;
pc=0.9;
% mu=0.1;
%% Initialization
tic;
empty_individual.Position=[];%%the individuals of population
empty_individual.Cost=[];%the fitness of population
empty_individual.Rank=[];%%the non-dominanted degree
empty_individual.CrowdingDistance=[];%%the crowding degree
empty_individual.DominatedCount=[];
empty_individual.DominationSet=[];
X=zeros(Popsize,dimsize);
pop=repmat(empty_individual,Popsize,1);

for i=1:Popsize
    pop(i).Position=2*rand(1,dimsize)-1;
    pop(i).Cost=DLWNN(pop(i).Position,train_y,train_x_norm,M,N,n,max_data,min_data);
end

% Non-dominated Sorting
[pop F]=NonDominatedSorting(pop);

% Calculate Crowding Distances
pop=CalcCrowdingDistance(pop,F);

PF=pop(F{1});
rePop=Popsize;
pop_3=pop;

%% NSGA-II Loop

for it=1:MaxIt
    
    it



    Fmax=0.9;
    Fmin=0.4;
    bestX=pop(1).Position;
    q=(MaxIt-it)/MaxIt;
    F=(Fmax-Fmin)*(MaxIt-it)/MaxIt+Fmin;
    pop_1=repmat(empty_individual,nMutation,1);

    for k=1:Popsize
        X(k,:)=pop(k).Position;
    end
    U=demutation(X,bestX,F,q,dimsize,dimRange,length(pop_1));%%����popm���������

    for k=1:nMutation 
       pop_1(k).Position=U(k,:);
       pop_1(k).Cost=DLWNN(U(k,:),train_y,train_x_norm,M,N,n,max_data,min_data);
    end

    pop_2=repmat(empty_individual,nCrossover/2,2);
    
    for k=1:nCrossover/2
        
        i1=BinaryTournamentSelection(pop);
        i2=BinaryTournamentSelection(pop);
        
        if i1==i2
            i2=BinaryTournamentSelection(pop); 
        end
        
        [pop_2(2*k-1).Position,pop_2(2*k).Position]=Crossover2(pop(i1).Position,pop(i2).Position,dimRange);
        
        pop_2(2*k-1).Cost=DLWNN(pop_2(2*k-1).Position,train_y,train_x_norm,M,N,n,max_data,min_data);
        pop_2(2*k).Cost=DLWNN(pop_2(2*k).Position,train_y,train_x_norm,M,N,n,max_data,min_data);
        
    end
    pop_2=pop_2(:);

    
    %%Integration of the original population and several cross-mutated populations
        pop=[pop
            pop_1
                pop_2
                    pop_3];
    
    % Non-dominated Sorting
    [pop F]=NonDominatedSorting(pop);

    % Calculate Crowding Distances
    pop=CalcCrowdingDistance(pop,F);
    
    % Sort Population
    [pop F]=SortPopulation(pop);
       
    PF=pop(F{1}); 
    NoPop=numel(PF);
    
%%elite selection
    if NoPop>rePop 
        pop=EliteSelection(PF,rePop);
    else
        pop=pop(1:rePop);
    end

    [pop F]=NonDominatedSorting(pop);
    pop=CalcCrowdingDistance(pop,F);
    
    [pop F]=SortPopulation(pop);

    PF=pop(F{1}); 
    
    NF=numel(PF);
    if NF>=2     
        mm=0.1;
        pop_3=repmat(empty_individual,NF,1);
        for k=1:NF
            pop_3(k).Position=Mutate(PF(k).Position,mm,dimRange);
            pop_3(k).Cost=DLWNN(pop_3(k).Position,train_y,train_x_norm,M,N,n,max_data,min_data);      
        end
    end
end

RunTime_DLWNN=toc;



